# Data term paper 2
rm(list = ls())
library(readxl)
library(dplyr)
library(zoo)
library(knitr) # Markdown 
library(dplyr) # Language
library(tidyr)
library(scales)# Scaling 
library(stringr)


# collecting 

# This wont run without SQL key 
con <- RMariaDB::dbConnect(RMariaDB::MariaDB(), groups = "capia")

# Airbnb data pr kommune 
# hver for seg eller aggregert
# roomsAvailable, roomsBooked, revenue
#roomsBooked=sum(reservation_rooms)
#roomsAvailable=sum(available_rooms)
#Inntekt=sum(revenue_nok)
########## pr kommune, pr mnd ############# 
main <- dplyr::tbl(con, 'view_materialized__us_airdna_month_performance') %>%
  dplyr::filter(airbnb_property_id!=-1) %>% # Added by Bjørn Ole as temp fix fot new homeaway data
  dplyr::filter(country=='Norge',
                municipality %in% c("Bergen","Oslo", "Trondheim", "Follo", "Romerike", 
                                    "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"),
                active==TRUE,
                keep_filter==TRUE) %>%
  #               date_start>= !!data$start & date_start<= !!data$end_date) %>%
  filter(!is.na(listing_type) & !is.na(bedrooms)) %>%
  filter(date_start > "2014-12-01") %>%
  dplyr::select(date_start, revenue_nok, reservation_rooms, available_rooms, municipality) %>%
  dplyr::group_by(date_start, municipality) %>%
  dplyr::summarise(revenue=sum(revenue_nok, na.rm = TRUE),
                   roomsBooked=sum(reservation_rooms, na.rm = TRUE),
                   roomsAvailable=sum(available_rooms, na.rm = TRUE),
                   availableUnits=n())%>%
  #dplyr::mutate(roomsOccupancy=roomsBooked/roomsAvailable)%>%
  dplyr::ungroup() %>%
  dplyr::arrange(municipality,date_start) %>%
  dplyr::collect() %>%
  dplyr::mutate(date_start = as.Date(date_start))# %>%

main$availableUnits <- as.numeric(main$availableUnits)

#  help(write_xlsx)
#writexl::write_xlsx(main,path = "/Users/orjan/airbnbprkommune")

# Prisindeks fra eiendom Norge 
prisindeks <- read_excel("Prisdata2019.xlsx")
prisindeks <- prisindeks[,c(1,4,6,7,9,12,14,16,17,22,23)]
colnames(prisindeks) <- c("date_start","Follo", "Oslo", "Romerike","Bergen","Tromsø","Hamar",
                          "Kristiansand","Stavanger", "Ålesund","Trondheim" )
prisindeks <- prisindeks[,-c(2,4)]

# husholdningsintekt pr kommune 
samletinntekt <- read_excel("samletinntekt.xlsx")
samletinntekt <- samletinntekt[,-c(16:28)]
colnames(samletinntekt) <- samletinntekt[3,]
samletinntekt <- samletinntekt[-c(1:3),]
names(samletinntekt)[1:2] <- paste(c("kommune","husholdning"))  # works
samletinntekt <- samletinntekt[1:423,]
samletinntekt$kommune <- substring(samletinntekt$kommune, 6)

# antall husholdninger
antallhusholdninger <- samletinntekt[,c(1,2,16:28)]
antallhusholdninger <- antallhusholdninger %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                        "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))
antallhusholdninger[1,1] <- "Oslo"
antallhusholdninger <- antallhusholdninger[,-2]

antallhusholdninger[, c(2:14)] <- sapply(antallhusholdninger[, c(2:14)], as.numeric)
okning <- 1.011
antallhusholdninger$`2018` <- antallhusholdninger$`2017`*okning
antallhusholdninger$`2019` <- antallhusholdninger$`2018`*okning


# median inntekt 
samletinntekt <- samletinntekt[,c(1:15)]
samletinntekt <- samletinntekt %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                      "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))
samletinntekt[1,1] <- "Oslo"
samletinntekt <- samletinntekt[,-2]
samletinntekt[, c(2:14)] <- sapply(samletinntekt[, c(2:14)], as.numeric)
okning <- 1.025
samletinntekt$`2018` <- samletinntekt$`2017`*okning
samletinntekt$`2019` <- samletinntekt$`2018`*okning


# arbeidsledighet 
arb <- read_excel("Registrerte1.xlsx")
colnames(arb) <- arb[3,]
arb <- arb[-c(1:3),]
names(arb)[1:2] <- paste(c("kommune","kjonn"))
arb <- arb[1:423,]
arb$kommune <- substring(arb$kommune, 6)
arb <- arb %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                        "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))
arb[1,1] <- "Oslo"
arb <- arb[,-2]
arb[, c(2:149)] <- sapply(arb[, c(2:149)], as.numeric)


# arbeidsledighet 
arbprob <- read_excel("RegHeltLedige.xlsx")
colnames(arbprob) <- arbprob[3,]
arbprob <- arbprob[-c(1:3),]
names(arbprob)[1:2] <- paste(c("kommune","alder"))
arbprob <- arbprob[1:423,]
arbprob$kommune <- substring(arbprob$kommune, 6)
arbprob <- arbprob %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                        "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))
arbprob[1,1] <- "Oslo"
arbprob <- arbprob[,-2]
arbprob[, c(2:149)] <- sapply(arbprob[, c(2:149)], as.numeric)


# rente
rente <- read_excel("Utlaan.xlsx")
rente <- rente[3:5,-c(1:26)]
colnames(rente) <- rente[1,]
rente <- rente[-1,]
rente <- rente[-2,]
rente$kommune <- "hele landet"

# årlig gjennomsnitt
aarrente <- read_excel("Bankutlansrente.xlsx")
aarrente <- aarrente[3:5,-c(1:23)]
colnames(aarrente) <- aarrente[1,]
aarrente <- aarrente[-c(1,3),]


# kvm pris 
# KvPris <- read_excel("KvPris.xlsx")
# colnames(KvPris) <- KvPris[3,]
# names(KvPris)[1:2] <- paste(c("kommune","type"))
# KvPris <- KvPris[4:195,]
# KvPris$kommune <- substring(KvPris$kommune, 6)
# writexl::write_xlsx(KvPris, path = "/Users/orjan/Desktop/UIT/Master_3.sem/Models for market analysis/term paper 2/hei.xlsx")
KvPris <- read_excel("KvPris8.xlsx")


# folkemengde 
Folkemengde <- read_excel("Folkemengde.xlsx")
Folkemengde$kommune <- substring(Folkemengde$kommune, 6)
Folkemengde <- Folkemengde %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                      "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))


# eneboliger  
enebolig <- read_excel("Godkjente (1).xlsx")
colnames(enebolig) <- enebolig[3,]
enebolig <- enebolig[-c(1:3),]
names(enebolig)[1:2] <- paste(c("kommune","type"))
enebolig$kommune <- substring(enebolig$kommune, 6)

godkjentEnebolig <- enebolig[,1:69]
igangsattEnebolig <- enebolig[,c(1,2,70:136)]
fullførtEnebolig <- enebolig[,c(1,2,137:203)]

godkjentEnebolig <- godkjentEnebolig %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                        "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))

igangsattEnebolig <- igangsattEnebolig %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                        "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))

fullførtEnebolig <- fullførtEnebolig %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                        "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))



# rekkehus   
rekkehus <- read_excel("rekkehus.xlsx")
colnames(rekkehus) <- rekkehus[3,]
rekkehus <- rekkehus[-c(1:3),]
names(rekkehus)[1:2] <- paste(c("kommune","type"))
rekkehus$kommune <- substring(rekkehus$kommune, 6)

godkjentRekkehus <- rekkehus[,1:69]
igangsattRekkehus <- rekkehus[,c(1,2,70:136)]
fullførtRekkehus <- rekkehus[,c(1,2,137:203)]

godkjentRekkehus <- godkjentRekkehus %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                        "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))

igangsattRekkehus <- igangsattRekkehus %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                        "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))

fullførtRekkehus <- fullførtRekkehus %>%
  filter(kommune %in% c("Bergen","Oslo kommune","Trondheim", "Romerike", 
                        "Ålesund", "Hamar", "Kristiansand", "Stavanger", "Tromsø"))



# main # airbnb 
# prisindeks #indeks på boligpris 
# antallhusholdninger #antall husholdninger i kommunen år 
# samletinntekt # median inntekt kommune år
# arb #arbeidsledighet måned 
# arbprob #arbeidsledighet i prosent måned 
# aarrente #gjennomsnittlig boliglånsrente årsbasis 
# rente # utlånsrente pr mnd kvartal 
# KvPris #kvm pris bolig kvartal
# Folkemengde # folk i kommunen år 
# godkjentEnebolig # godkjente bygde eneboliger pr kvartal 
# igangsattEnebolig # igangsatte eneboliger pr kvartal 
# fullførtEnebolig # fullførte eneboliger pr kvartal 
# godkjentRekkehus # godkjente bygde rekkehus pr kvartal 
# igangsattRekkehus # igangsatte rekkehus pr kvartal 
# fullførtRekkehus # fullførte rekkehus pr kvartal 

# from wide to long 

prisindeks$date_start <- as.factor(prisindeks$date_start) # setting as factor so could use fun melt 
prisindeks <- prisindeks %>% 
  gather(variable, value, -date_start) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 



antallhusholdninger <- antallhusholdninger %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
antallhusholdninger <- antallhusholdninger[order(antallhusholdninger$kommune),]


samletinntekt <- samletinntekt %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
samletinntekt <- samletinntekt[order(samletinntekt$kommune),]


arb <- arb %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
arb <- arb[order(arb$kommune),]

arbprob <- arbprob %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
arbprob <- arbprob[order(arbprob$kommune),]

aarrente$kommune <- "Hele landet"
aarrente <- aarrente %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
aarrente$value <- as.numeric(aarrente$value)


rente <- rente %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
rente$value <- as.numeric(rente$value)


KvPrisEnebolig <- KvPris[seq(1, nrow(KvPris), 3), ]
KvPrisEnebolig <- KvPrisEnebolig[,-2]
KvPrisEnebolig[, c(2:56)] <- sapply(KvPrisEnebolig[, c(2:56)], as.numeric)
KvPrisEnebolig <- KvPrisEnebolig %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
KvPrisEnebolig <- KvPrisEnebolig[order(KvPrisEnebolig$kommune),]

KvPrisSmåhus <- KvPris[seq(2, nrow(KvPris), 3), ]
KvPrisSmåhus <- KvPrisSmåhus[,-2]
KvPrisSmåhus[, c(2:56)] <- sapply(KvPrisSmåhus[, c(2:56)], as.numeric)
KvPrisSmåhus <- KvPrisSmåhus %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
KvPrisSmåhus <- KvPrisSmåhus[order(KvPrisSmåhus$kommune),]


KvPrisBlokk <- KvPris[seq(3, nrow(KvPris), 3), ]
KvPrisBlokk <- KvPrisBlokk[,-2]
KvPrisBlokk[, c(2:56)] <- sapply(KvPrisBlokk[, c(2:56)], as.numeric)
KvPrisBlokk <- KvPrisBlokk %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
KvPrisBlokk <- KvPrisBlokk[order(KvPrisBlokk$kommune),]


Folkemengde[1,1] <- "Oslo"
Folkemengde <- Folkemengde %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
Folkemengde <- Folkemengde[order(Folkemengde$kommune),]



godkjentEnebolig[1,1] <- "Oslo"
godkjentEnebolig <- godkjentEnebolig[,-2]
godkjentEnebolig[, c(2:68)] <- sapply(godkjentEnebolig[, c(2:68)], as.numeric)
godkjentEnebolig <- godkjentEnebolig %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
godkjentEnebolig <- godkjentEnebolig[order(godkjentEnebolig$kommune),]


igangsattEnebolig[1,1] <- "Oslo"
igangsattEnebolig <- igangsattEnebolig[,-2]
igangsattEnebolig[, c(2:68)] <- sapply(igangsattEnebolig[, c(2:68)], as.numeric)
igangsattEnebolig <- igangsattEnebolig %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
igangsattEnebolig <- igangsattEnebolig[order(igangsattEnebolig$kommune),]

fullførtEnebolig[1,1] <- "Oslo"
fullførtEnebolig <- fullførtEnebolig[,-2]
fullførtEnebolig[, c(2:68)] <- sapply(fullførtEnebolig[, c(2:68)], as.numeric)
fullførtEnebolig <- fullførtEnebolig %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
fullførtEnebolig <- fullførtEnebolig[order(fullførtEnebolig$kommune),]


godkjentRekkehus[1,1] <- "Oslo"
godkjentRekkehus <- godkjentRekkehus[,-2]
godkjentRekkehus[, c(2:68)] <- sapply(godkjentRekkehus[, c(2:68)], as.numeric)
godkjentRekkehus <- godkjentRekkehus %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
godkjentRekkehus <- godkjentRekkehus[order(godkjentRekkehus$kommune),]


igangsattRekkehus[1,1] <- "Oslo"
igangsattRekkehus <- igangsattRekkehus[,-2]
igangsattRekkehus[, c(2:68)] <- sapply(igangsattRekkehus[, c(2:68)], as.numeric)
igangsattRekkehus <- igangsattRekkehus %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
igangsattRekkehus <- igangsattRekkehus[order(igangsattRekkehus$kommune),]

fullførtRekkehus[1,1] <- "Oslo"
fullførtRekkehus <- fullførtRekkehus[,-2]
fullførtRekkehus[, c(2:68)] <- sapply(fullførtRekkehus[, c(2:68)], as.numeric)
fullførtRekkehus <- fullførtRekkehus %>% 
  gather(variable, value, -`kommune`) %>% 
  mutate(variable = factor(variable)) %>% 
  as.data.frame() # melting with years as desiding variable 
fullførtRekkehus <- fullførtRekkehus[order(fullførtRekkehus$kommune),]


#main # airbnb 
#prisindeks #indeks på boligpris 
#antallhusholdninger #antall husholdninger i kommunen år 
#samletinntekt # median inntekt kommune år
#arb #arbeidsledighet måned 
#arbprob #arbeidsledighet i prosent måned 
#aarrente #gjennomsnittlig boliglånsrente årsbasis 
# rente # utlånsrente pr mnd kvartal 
#KvPrisEnebolig #kvm pris bolig enebolig kvartal
#KvPrisSmåhus # kvm pris bolig småhus kvartal
#KvPrisBlokk# kvm pris bolig blokk kvartal
# Folkemengde # folk i kommunen år 
#godkjentEnebolig # godkjente bygde eneboliger pr kvartal 
#igangsattEnebolig # igangsatte eneboliger pr kvartal 
#fullførtEnebolig # fullførte eneboliger pr kvartal 
#godkjentRekkehus # godkjente bygde rekkehus pr kvartal 
#igangsattRekkehus # igangsatte rekkehus pr kvartal 
#fullførtRekkehus # fullførte rekkehus pr kvartal 

# merging 

# prisindeks og airbnb 
prisindeks$date_start <- as.Date(prisindeks$date_start)
main$municipality <- as.factor(main$municipality)
main$availableUnits <- as.numeric(main$availableUnits)
colnames(main) <- c("date_start","variable" ,"revenue","roomsBooked","roomsAvailable","availableUnits")

df1 <- left_join(prisindeks,main, by= c("date_start" = "date_start", "variable" = "variable")) #airbnb og prisindeks 

colnames(df1) <- c("date_start", "municipality", "house_P_index", "AIRrev", 
                   "AIRroomBook" ,"AIRroomAv", "AIRavUn")
df1[is.na(df1)] <- 0


# arb 
ym = str_split_fixed(arb$variable, "M", 2)
arb$year = as.numeric(ym[,1])
arb$month = as.numeric(ym[,2])
arb$date_start = as.Date(paste(arb$year, arb$month, 1, sep="-"), "%Y-%m-%d")
arb <- arb[,c(6,1,3)]
colnames(arb) <- c("date_start","municipality", "unemploy")
arb$municipality <- as.factor(arb$municipality)

df1 <- left_join(df1, arb, by= c("date_start" = "date_start", "municipality" = "municipality"))


# arbprob
ym = str_split_fixed(arbprob$variable, "M", 2)
arbprob$year = as.numeric(ym[,1])
arbprob$month = as.numeric(ym[,2])
arbprob$date_start = as.Date(paste(arbprob$year, arbprob$month, 1, sep="-"), "%Y-%m-%d")
arbprob <- arbprob[,c(6,1,3)]
colnames(arbprob) <- c("date_start","municipality", "unemployPer")
arbprob$municipality <- as.factor(arbprob$municipality)

df1 <- left_join(df1, arbprob, by= c("date_start" = "date_start", "municipality" = "municipality"))


# aarrente 
aarrente$variable <- as.character(aarrente$variable)
df1$year <- substring(df1$date_start, 1,4)

df1 <- left_join(df1, aarrente, by= c("year" = "variable"))
df1 <- df1[,-11]

colnames(df1)[11] <- "interestRate"


# antall husholdninger, medianinntekt og folkemengde 
antallhusholdninger$variable <- as.character(antallhusholdninger$variable)
antallhusholdninger$kommune <- as.factor(antallhusholdninger$kommune)
df1 <- left_join(df1, antallhusholdninger, by= c("year" = "variable", "municipality" = "kommune"))
colnames(df1)[12] <- "num_houses"



samletinntekt$variable <- as.character(samletinntekt$variable)
samletinntekt$kommune <- as.factor(samletinntekt$kommune)
df1 <- left_join(df1, samletinntekt, by= c("year" = "variable", "municipality" = "kommune"))
colnames(df1)[13] <- "av_income"


Folkemengde$variable <- as.character(Folkemengde$variable)
Folkemengde$kommune <- as.factor(Folkemengde$kommune)
df1 <- left_join(df1, Folkemengde, by= c("year" = "variable", "municipality" = "kommune"))
colnames(df1)[14] <- "numOFpeople"


# rente
rente$variable <- as.character(rente$variable)
rente$variable <- str_replace_all(rente$variable, c("K1" = "-01-01", "K2" = "-04-01",
                                  "K3" = "-07-01", "K4" = "-10-01"))
rente$variable <- as.Date(rente$variable)
df1 <- left_join(df1, rente, by= c("date_start" = "variable"))
df1 <- df1[,-c(10,15)]
colnames(df1)[14] <- "interestRateQ"


# kvmpris 
KvPrisEnebolig$variable <- as.character(KvPrisEnebolig$variable)
KvPrisEnebolig$variable <- str_replace_all(KvPrisEnebolig$variable, c("K1" = "-01-01", "K2" = "-04-01",
                                                    "K3" = "-07-01", "K4" = "-10-01"))
KvPrisEnebolig$variable <- as.Date(KvPrisEnebolig$variable)
KvPrisEnebolig$kommune <- as.factor(KvPrisEnebolig$kommune)
df1 <- left_join(df1, KvPrisEnebolig, by= c("date_start" = "variable", "municipality" = "kommune"))
colnames(df1)[15] <- "kvmPriceEnebol"


KvPrisSmåhus$variable <- as.character(KvPrisSmåhus$variable)
KvPrisSmåhus$variable <- str_replace_all(KvPrisSmåhus$variable, c("K1" = "-01-01", "K2" = "-04-01",
                                                                      "K3" = "-07-01", "K4" = "-10-01"))
KvPrisSmåhus$variable <- as.Date(KvPrisSmåhus$variable)
KvPrisSmåhus$kommune <- as.factor(KvPrisSmåhus$kommune)
df1 <- left_join(df1, KvPrisSmåhus, by= c("date_start" = "variable", "municipality" = "kommune"))
colnames(df1)[16] <- "kvmPriceSmaahus"


KvPrisBlokk$variable <- as.character(KvPrisBlokk$variable)
KvPrisBlokk$variable <- str_replace_all(KvPrisBlokk$variable, c("K1" = "-01-01", "K2" = "-04-01",
                                                                  "K3" = "-07-01", "K4" = "-10-01"))
KvPrisBlokk$variable <- as.Date(KvPrisBlokk$variable)
KvPrisBlokk$kommune <- as.factor(KvPrisBlokk$kommune)
df1 <- left_join(df1, KvPrisBlokk, by= c("date_start" = "variable", "municipality" = "kommune"))
colnames(df1)[17] <- "kvmPriceBlokk"


# godkjente bygde eneboliger pr kvartal
godkjentEnebolig$variable <- as.character(godkjentEnebolig$variable)
godkjentEnebolig$variable <- str_replace_all(godkjentEnebolig$variable, c("K1" = "-01-01", "K2" = "-04-01",
                                                                "K3" = "-07-01", "K4" = "-10-01"))
godkjentEnebolig$variable <- as.Date(godkjentEnebolig$variable)
godkjentEnebolig$kommune <- as.factor(godkjentEnebolig$kommune)
df1 <- left_join(df1, godkjentEnebolig, by= c("date_start" = "variable", "municipality" = "kommune"))
colnames(df1)[18] <- "godkjent_enebol"


# igangsatte eneboliger pr kvartal 
igangsattEnebolig$variable <- as.character(igangsattEnebolig$variable)
igangsattEnebolig$variable <- str_replace_all(igangsattEnebolig$variable, c("K1" = "-01-01", "K2" = "-04-01",
                                                                          "K3" = "-07-01", "K4" = "-10-01"))
igangsattEnebolig$variable <- as.Date(igangsattEnebolig$variable)
igangsattEnebolig$kommune <- as.factor(igangsattEnebolig$kommune)
df1 <- left_join(df1, igangsattEnebolig, by= c("date_start" = "variable", "municipality" = "kommune"))
colnames(df1)[19] <- "igangsatt_enebol"



# fullførte eneboliger pr kvartal 
fullførtEnebolig$variable <- as.character(fullførtEnebolig$variable)
fullførtEnebolig$variable <- str_replace_all(fullførtEnebolig$variable, c("K1" = "-01-01", "K2" = "-04-01",
                                                                            "K3" = "-07-01", "K4" = "-10-01"))
fullførtEnebolig$variable <- as.Date(fullførtEnebolig$variable)
fullførtEnebolig$kommune <- as.factor(fullførtEnebolig$kommune)
df1 <- left_join(df1, fullførtEnebolig, by= c("date_start" = "variable", "municipality" = "kommune"))
colnames(df1)[20] <- "fullfort_enebol"


# godkjente bygde rekkehus pr kvartal 
godkjentRekkehus$variable <- as.character(godkjentRekkehus$variable)
godkjentRekkehus$variable <- str_replace_all(godkjentRekkehus$variable, c("K1" = "-01-01", "K2" = "-04-01",
                                                                          "K3" = "-07-01", "K4" = "-10-01"))
godkjentRekkehus$variable <- as.Date(godkjentRekkehus$variable)
godkjentRekkehus$kommune <- as.factor(godkjentRekkehus$kommune)
df1 <- left_join(df1, godkjentRekkehus, by= c("date_start" = "variable", "municipality" = "kommune"))
colnames(df1)[21] <- "godkjent_rekke"




# igangsatte rekkehus pr kvartal 
igangsattRekkehus$variable <- as.character(igangsattRekkehus$variable)
igangsattRekkehus$variable <- str_replace_all(igangsattRekkehus$variable, c("K1" = "-01-01", "K2" = "-04-01",
                                                                          "K3" = "-07-01", "K4" = "-10-01"))
igangsattRekkehus$variable <- as.Date(igangsattRekkehus$variable)
igangsattRekkehus$kommune <- as.factor(igangsattRekkehus$kommune)
df1 <- left_join(df1, igangsattRekkehus, by= c("date_start" = "variable", "municipality" = "kommune"))
colnames(df1)[22] <- "igangsatt_rekke"




# fullført rekkehus pr kvartal 
fullførtRekkehus$variable <- as.character(fullførtRekkehus$variable)
fullførtRekkehus$variable <- str_replace_all(fullførtRekkehus$variable, c("K1" = "-01-01", "K2" = "-04-01",
                                                                            "K3" = "-07-01", "K4" = "-10-01"))
fullførtRekkehus$variable <- as.Date(fullførtRekkehus$variable)
fullførtRekkehus$kommune <- as.factor(fullførtRekkehus$kommune)
df1 <- left_join(df1, fullførtRekkehus, by= c("date_start" = "variable", "municipality" = "kommune"))
colnames(df1)[23] <- "fullfort_rekke"

df1$municipality <- as.factor(df1$municipality)

# ferdig merge alle datasett inn til df1 

# cleaning 

# bruker zoo for å fylle inn NA's på kvartalvise data 

df1$unemploy <- na.locf(df1$unemploy, na.rm = F)
df1$unemployPer <- na.locf(df1$unemployPer, na.rm = F)
df1$godkjent_enebol <- na.locf(df1$godkjent_enebol, na.rm = F)
df1$igangsatt_enebol <- na.locf(df1$igangsatt_enebol, na.rm = F)
df1$fullfort_enebol <- na.locf(df1$fullfort_enebol, na.rm = F)
df1$godkjent_rekke <- na.locf(df1$godkjent_rekke, na.rm = F)
df1$igangsatt_rekke <- na.locf(df1$igangsatt_rekke, na.rm = F)
df1$fullfort_rekke <- na.locf(df1$fullfort_rekke, na.rm = F)

# setter inn 0 før 2006 første dataobservasjon
max.date <- '2005-12-01'
df1$kvmPriceEnebol[is.na(df1$kvmPriceEnebol) & df1$date_start <= max.date] <- 0
df1$kvmPriceSmaahus[is.na(df1$kvmPriceSmaahus) & df1$date_start <= max.date] <- 0
df1$kvmPriceBlokk[is.na(df1$kvmPriceBlokk) & df1$date_start <= max.date] <- 0

df1$kvmPriceEnebol <- na.locf(df1$kvmPriceEnebol, na.rm = F)
df1$kvmPriceSmaahus <- na.locf(df1$kvmPriceSmaahus, na.rm = F)
df1$kvmPriceBlokk <- na.locf(df1$kvmPriceBlokk, na.rm = F)

min.date <- "2019-01-01"
df1$interestRate[is.na(df1$interestRate) & df1$date_start >= min.date] <- 2.9

max.date <- '2004-12-01'
df1$num_houses[is.na(df1$num_houses) & df1$date_start <= max.date] <- 0
df1$av_income[is.na(df1$av_income) & df1$date_start <= max.date] <- 0

max.date <- '2006-12-01'
df1$numOFpeople[is.na(df1$numOFpeople) & df1$date_start <= max.date] <- 0

max.date <- '2008-09-01'
df1$interestRateQ[is.na(df1$interestRateQ) & df1$date_start <= max.date] <- 0
df1$interestRateQ <- na.locf(df1$interestRateQ, na.rm = F)

df1[is.na(df1)] <- 0


# replecating crime data 
df1 <- df1[,c(1,2,3,15,16,17,4,5,6,7,8,9,10,14,11,12,13,18,19,20,21,22,23)]
df1$AIRrevPerHouse <- df1$AIRrev/df1$num_houses
df1[is.na(df1)] <- 0


#getwd()
# this is the file used in the paper
#writexl::write_xlsx(df1,path = "/selectedpath/termpaper2data.xlsx")

