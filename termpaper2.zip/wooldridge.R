rm(list=ls())
require(mosaic)
require(broom)
browseURL("http://fmwww.bc.edu/ec-p/data/wooldridge/datasets.list.html")

library(foreign)
kielmc <- read.dta("http://fmwww.bc.edu/ec-p/data/wooldridge/kielmc.dta")
head(kielmc)

#options(scipen=999)

# Separate regressions for 1978 and 1981
table(kielmc$year)
kielmc %>% group_by(year) %>% do(tidy(lm(rprice~nearinc, data=.))) 
kielmc %>% group_by(year) %>% do(glance(lm(rprice~nearinc, data=.))) %>% round(.,2)

# Joint regression including an interaction term
# Table 13.2, model (1)
kielmc %>% do(tidy(lm(rprice~nearinc*y81, data=.)))
kielmc %>% do(glance(lm(rprice~nearinc*y81, data=.))) %>% round(.,2)

# Table 13.2, model (2)
kielmc %>% do(tidy(lm(rprice~nearinc*y81+age+I(age^2), data=.)))
kielmc %>% do(glance(lm(rprice~nearinc*y81+age+I(age^2), data=.))) %>% round(.,2)

# Table 13.2, model (3)
names(kielmc)
kielmc %>% do(tidy(lm(rprice~nearinc*y81+age+I(age^2)+intst+land+area+rooms+baths, data=.)))
kielmc %>% do(glance(lm(rprice~nearinc*y81+age+I(age^2)+intst+land+area+rooms+baths, data=.))) %>% round(.,2)

# log-lin model
kielmc %>% do(tidy(lm(log(rprice)~nearinc*y81, data=.)))
kielmc %>% do(glance(lm(log(rprice)~nearinc*y81, data=.))) %>% round(.,2)
100*(exp(-0.06264902)-1)
rm(kielmc)

# First Difference Models (Two-Period Panel Data Analysis)
library(plm)
#library(lmtest)

crime2 <- read.dta("http://fmwww.bc.edu/ec-p/data/wooldridge/crime2.dta")
head(crime2)

names(crime2)
PDcrime2 <- pdata.frame(crime2, index=46 )
pdim(PDcrime2)

# manually calculate first differences:
PDcrime2$Dcrmrte <- diff(PDcrime2$crmrte)
PDcrime2$Dunem   <- diff(PDcrime2$unem)

# Display selected variables for observations 1-6:
#PDcrime2[1:6,c("id","time","year","crmrte","Dcrmrte","unem","Dunem")]

PDcrime2 %>% select(id,time,year,crmrte,Dcrmrte,unem,Dunem) %>% head(.,6)

# Estimate FD model with lm on differenced data:
#coeftest( lm(Dcrmrte~Dunem, data=PDcrime2) )
PDcrime2 %>% group_by(time) %>% do(tidy(lm(crmrte~unem, data=.)))

PDcrime2 %>% do(tidy(lm(Dcrmrte~Dunem, data=.)))
PDcrime2 %>% do(glance(lm(Dcrmrte~Dunem, data=.)))

# Estimate FD model with plm on original data:
#coeftest(plm(crmrte~unem, data=PDcrime2, model="fd") )

PDcrime2 %>% do(tidy(plm(crmrte~unem, model="fd", data=.)))

# Panel Data Calculations, see URFIE, p. 202-203.

# Note that to do plm::between, plm::lag, plm::lead, you need to load the plm package
# after mosaic and/or dplyr, see message:
# The following objects are masked from â€˜package:dplyrâ€™:  between, lag, lead

crime4 <- read.dta("http://fmwww.bc.edu/ec-p/data/wooldridge/crime4.dta")

# Generate pdata.frame:
crime4.p <- pdata.frame(crime4, index=c("county","year") )

# Calculations within the pdata.frame:
crime4.p$cr.l <- lag(crime4.p$crmrte)
crime4.p$cr.d <- diff(crime4.p$crmrte)
crime4.p$cr.B <- Between(crime4.p$crmrte)
crime4.p$cr.W <- Within(crime4.p$crmrte) # demeaning

# Display selected variables for observations 1-16:
crime4.p[1:16,c("county","year","crmrte","cr.l","cr.d","cr.B","cr.W")]
