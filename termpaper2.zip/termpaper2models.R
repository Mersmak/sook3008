rm(list = ls())
# For å laste inn gammel versjon av mlogit pakke 
#packageurl <- "https://cran.r-project.org/src/contrib/Archive/mlogit/mlogit_0.3-0.tar.gz"
#install.packages(packageurl, repos=NULL, type="source")
library(mlogit)
sessionInfo()

data("TollRoad", package = "mlogit")
data("Car")
data("Beef")
data("Electricity")


{
  "query": [
    {
      "code": "Utlanstype",
      "selection": {
        "filter": "item",
        "values": [
          "04",
          "70",
          "30"
          ]
      }
    },
    {
      "code": "Sektor",
      "selection": {
        "filter": "item",
        "values": [
          "04b",
          "04a"
          ]
      }
    },
    {
      "code": "Rentebinding",
      "selection": {
        "filter": "item",
        "values": [
          "99",
          "08",
          "12",
          "11",
          "06"
          ]
      }
    },
    {
      "code": "ContentsCode",
      "selection": {
        "filter": "item",
        "values": [
          "RenterNyeBolig"
          ]
      }
    },
    {
      "code": "Tid",
      "selection": {
        "filter": "item",
        "values": [
          "2013M12",
          "2014M01",
          "2014M02",
          "2019M08",
          "2019M09"
          ]
      }
    }
    ],
  "response": {
    "format": "json-stat2"
  }
}

