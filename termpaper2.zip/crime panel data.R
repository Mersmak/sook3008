rm(list=ls())
#' `r knitr::opts_chunk$set(comment=NA)`

suppressPackageStartupMessages(require(pacman))
#p_load(xtable,knitr,broom,dplyr,mosaic,AER,lmtest,car,plm)
p_load(mosaic,plm,stargazer)

getwd()
setwd("~/undervisning/SOK3008")


#' **15.22**
#' Data definition file
browseURL("http://www.principlesofeconometrics.com/poe5/data/def/crime.def")
load(url("http://www.principlesofeconometrics.com/poe5/data/rdata/crime.rdata"))

str(crime)
crimePDF <- pdata.frame(crime, index=c("county", "year"))
pdim(crimePDF)

#' a. **A priori assumptions:**  
#' (i) If deterrence increases crime rates should drop.
#' (ii) If wages in the private sector increase the return to legal activities increases relative to the
#' return to illegal activities. Therefore crime rates should drop.
#' (iii) Higher population density should be linked with a higher residential crime rate.
#' (iv) Young males are the most likely demographic group to be involved in illegal activities.
#' Thus, an increase in the percentage of young males should increase the crime rate.  

#' b. **A pooled OLS model**    
# lcrmrte        log(crimes committed per person)  
# lprbarr        log('probability' of arrest)  
# lprbconv       log('probability' of conviction)  
# lprbpris       log('probability' of prison sentenc)  
# lavgsen        log(avg. sentence, days)  
# lwmfg          log(wkly wage, manufacturing)  

#' OLS model  
noquote(names(crime))
lcrmrte.ols <- lm(lcrmrte ~ lprbarr+lprbconv+lprbpris+lavgsen+lwmfg, data=crime)
summary(lcrmrte.ols)

#' Variables measuring deterrence of the legal system:  
#' This is a log-log model, hence all parameters are interpreted as elasticities.  
#' lprbarr : when the 'probability' of arrest increases by 1% the crimes committed per person (or crimerate)
#' decreases by `r round(coef(lcrmrte.ols)[2],2)` %.
#' lprbconv : when the 'probability' of conviction increases by 1% the crimes committed per person (or crimerate)
#' decreases by `r round(coef(lcrmrte.ols)[3],2)` %.  
#' lprbpris : when the 'probability' of prison sentence increases by 1% the crimes committed per person (or crimerate)
#' increases by `r round(coef(lcrmrte.ols)[4],2)` %. This is somewhat surprising.  
#' lavgsen : when the avg. sentence, days increases by 1% the crimes committed per person (or crimerate)
#' decreases by `r round(coef(lcrmrte.ols)[5],2)` %.    

#' If wages, measured by the lwmfg : wkly wage, manufacturing increases by 1% the crimes committed per person (or crimerate)
#' increases by `r round(coef(lcrmrte.ols)[6],2)` %. This is somewhat surprising.  

#' For the variables that describe the deterrence effect of the legal system. We would expect that the coefficients
#' of these variables would be negative. We find that all of these coefficients are negative except for the coefficient of
#' LPRBPRIS. The variable LWMFG, which represents wages in the private sector, has a positive coefficient that is not
#' consistent with our expectations.
#'   
#' All coefficients are significantly different from zero at a 5% level of significance except for the
#' coefficient of LAVGSEN.  

#' **c. The Fixed Effects model**    
lcrmrte.fixed <- plm(lcrmrte ~ lprbarr+lprbconv+lprbpris+lavgsen+lwmfg, data=crimePDF, model = "within")
summary(lcrmrte.fixed)

#' Both models in the same output:  
stargazer(lcrmrte.ols, lcrmrte.fixed, type = "text")

#' All estimated coefficients have the expected sign except for LAVGSEN. Moreover, all
#' estimated coefficients are significantly different from zero at a 5% level of significance except
#' for the coefficient for LAVGSEN (the avg. sentence, days).  

#' (ii) The coefficient on LPRBARR suggests that a 1% increase in the probability of being
#' arrested results in a `r round(coef(lcrmrte.fixed)[1],2)` % decrease in the crime rate.
#' This estimated elasticity is about one third (`r round(coef(lcrmrte.fixed)[1]/coef(lcrmrte.ols)[2],2)`) of the
#' estimated elasticity from the pooled OLS model. Thus, once we allow for county heterogeneity, the
#' deterrent effect of being arrested is much less.  

#' (iii) The coefficient on LAVGSEN suggests that a 1% increase in the average prison sentence 
#' results in a `r round(coef(lcrmrte.fixed)[4],2)` % increase in the crime rate.  
#' However, a two tail t-test on the significance this estimate yields a t-statistic of
#' `r round(broom::tidy(lcrmrte.fixed)[4,4],3)` and a p-value of `r round(broom::tidy(lcrmrte.fixed)[4,5],3)`. Thus, a null hypothesis that
#' the coefficient of LAVGSEN is zero is not rejected. There is no support for the idea that longer
#' prison sentences are a deterrent to the crimerate.  

#' d. **F-test on equal intercept in the Fixed Effects model**  
#' This is a histogram on all the 90 intercepts:
fixef(lcrmrte.fixed, type = "level") %>% histogram(., width=0.1)

#' Do the F-test (equation 15.20)
broom::glance(lcrmrte.ols) # SSER
broom::glance(lcrmrte.fixed) # SSEU

SSER = broom::glance(lcrmrte.ols)$deviance
SSEU = broom::glance(lcrmrte.fixed)$deviance
N = length(fixef(lcrmrte.fixed))
NT = length(crimePDF$county)
K = length(coef(lcrmrte.fixed))

#' F-value
((SSER-SSEU)/(N-1))/(SSEU/(NT-N-K))
#' Critical F
qf(0.95, N-1, NT-N-K)

#' To test $H_0 : \beta_{1,1} = \beta_{1,2} = ... = \beta_{1,90}$ against the alternative that not all of the intercepts are equal,
#' we use the usual F-test for testing a set of linear restrictions.
#' The calculated value is F = `r round(((SSER-SSEU)/(N-1))/(SSEU/(NT-N-K)), 3)`,
#' while the 5% critical F-value is; F(0.95,`r (N-1)`, `r (NT-N-K)`), F = `r round(qf(0.95, N-1, NT-N-K),3)`.
#' The associated p-value is `r pf(((SSER-SSEU)/(N-1))/(SSEU/(NT-N-K)),df1=N-1,df2=NT-N-K, lower.tail=FALSE)`.
#' Hence, we reject $H_0$ and conclude that the county level effects are not all zero.
#' We reject the null hypothesis that there are no individual differences among counties.  

#' e. **Policy implications**
#' According to the fixed effects estimates, the explanatory variables which have the expected
#' signs and a significant effect on the crime rate are LPRBARR (the probability of being
#' arrested), LPRBCONV (the probability of being convicted), LPRBPRIS (the probability of prison sentence),
#' LWMFG (wkly wage, manufacturing). Out of these variables, those that have the largest effect
#' on crime rate, and are reasonable to implement as public policy, will be the most effective in
#' dealing with crime. Improving policing and court policies that increase the probability of arrest,
#' conviction and imprisonment are likely to be effective, but lengthening the term of
#' imprisonment is not (LAVGSEN). Opportunities for higher wages is also likely to be productive directions for public policy.  

#' **Why is:**  
#' ldensity : log(density) people per sq. mile  
#' lpctymle : log(pctymle) percent young male  
#' not included in the model, it is mentioned in a.?    

ols.mod2 = update(lcrmrte.ols, . ~ . +ldensity+lpctymle)
fixed.mod2 = update(lcrmrte.fixed, . ~ . +ldensity+lpctymle)

#' Both updated models in the same output:  
stargazer(ols.mod2, fixed.mod2, type = "text")

#####################################################
#' --------- 15.29 ----------------------------------  
#####################################################

rm(list=ls())

suppressPackageStartupMessages(require(pacman))
#p_load(xtable,knitr,broom,dplyr,mosaic,AER,lmtest,car,plm)
p_load(mosaic,plm,stargazer)

#' Data definition file
#browseURL("http://www.principlesofeconometrics.com/poe5/data/def/crime.def")
load(url("http://www.principlesofeconometrics.com/poe5/data/rdata/crime.rdata"))

crimePDF <- pdata.frame(crime, index=c("county", "year"))
pdim(crimePDF)

noquote(names(crime))

#' a.
#' Estimate the reduced form (1st stage ) of the endogenous variable, with the two instruments
lpolpc.red_form <- lm(lpolpc ~ lprbarr+lprbconv+lavgsen+lwmfg+west+urban+ltaxpc+lmix,
                      data=crime)
summary(lpolpc.red_form)

require(car)
#' Test of joint significanse of the two IV
linearHypothesis(lpolpc.red_form, c("ltaxpc=0", "lmix=0"))

require(broom)
tidy(lpolpc.red_form)

#' The two instruments have positive coefficients and are significant individually,
#' with t-values of `r tidy(lpolpc.red_form)[8,4]` and `r tidy(lpolpc.red_form)[9,4]`.
#' The joint F-test of their joint significance is
#' `r linearHypothesis(lpolpc.red_form, c("ltaxpc=0", "lmix=0"))$F[2]` > 10 the rule of thumb value.
#' Thus we can reject the null hypothesis that the IV are weak using this criterion.

#' b.
require(sem)
#' 2SLS Estimation 
lcrmrte.2sls <- tsls(lcrmrte ~ lpolpc+lprbarr+lprbconv+lavgsen+lwmfg+west+urban,
                     ~ lprbarr+lprbconv+lavgsen+lwmfg+west+urban+ltaxpc+lmix,
                     data = crime)
summary(lcrmrte.2sls)

#' The deterrence variables, the log of the probability of arrest (LPRBARR),
#' the log of the probability of conviction (LPRBCONV),
#' the log of average prison sentence (LAVGSEN), all have negative
#' and significant coefficients, indicating that they are having the desired effect.
#' The log of police per capita has a positive coefficient
#' and is significant at the 10% level.

#' c. Testing for exogeneity
#' http://eclr.humanities.manchester.ac.uk/index.php/IV_in_R

#' Hausman test
lcrmrte.ols_w_1stage_res <- lm(lcrmrte ~ lpolpc+lprbarr+lprbconv+lavgsen+lwmfg+west+urban+
                                 resid(lpolpc.red_form), data = crime)

summary(lcrmrte.ols_w_1stage_res)

#' Hausman Wu test
library(lmtest)
HausWutest <- waldtest(lcrmrte.ols_w_1stage_res,.~.-resid(lpolpc.red_form))
print(HausWutest)

#' Including the first stage residuals into the equation and estimating
#' it by OLS we find that the first stage residuals have a coefficient of
#' 0.1048 and a t = 0.78 (F = 0.6083 with p = 0.4358).
#' Thus based on this test we do not find evidence that LPOLPC is endogenous.
#' The Sargan test of the validity of the surplus instrument yields:

Sargan_reg <- lm(resid(lcrmrte.2sls) ~ lprbarr+lprbconv+lavgsen+lwmfg+west+urban+ltaxpc+lmix,
                 data=crime)
Sargan_reg_sm <- summary(Sargan_reg)

Sargan_test <- Sargan_reg_sm$r.squared*nrow(crime)
print(Sargan_test)
print(1-pchisq(Sargan_test,1))  # prints p-value

#' Thus we reject the validity of the surplus IV, making the 2SLS results suspect at best.

#' d. The Reduced Form Fixed Effects model
lpolpc.red_form.fix <- plm(lpolpc ~ lprbarr+lprbconv+lavgsen+lwmfg+west+urban+ltaxpc+lmix,
                           data=crimePDF, model = "within")

summary(lpolpc.red_form.fix)

#' Both of the instruments are significant at the 5% level.
#' Their joint test of significance yields an F:
linearHypothesis(lpolpc.red_form.fix, c("ltaxpc=0", "lmix=0"))
#' which indicates they are statistically significant.

#. Fixed Effects 2SLS
lcrmrte.2sls.fix <- plm(lcrmrte ~ lpolpc+lprbarr+lprbconv+lavgsen+lwmfg+west+urban
                        | lprbarr+lprbconv+lavgsen+lwmfg+west+urban+ltaxpc+lmix,
                        data=crimePDF, model = "within")

summary(lcrmrte.2sls.fix)
#' The deterrent variables behave as before, with the log of per capita police still
#' positive and significant.

#' f.
#' Hausman test
lcrmrte.fixed_w_1stage_res <- plm(lcrmrte ~ lpolpc+lprbarr+lprbconv+lavgsen+lwmfg+west+urban+
                                    resid(lpolpc.red_form.fix),
                                  data=crimePDF, model = "within")

summary(lcrmrte.fixed_w_1stage_res)

HausWutest.fixed <- waldtest(lcrmrte.fixed_w_1stage_res,.~.-resid(lpolpc.red_form.fix))
print(HausWutest.fixed)

#' Thus using the within data we find (weak) endogeneity of the log of police
#' per capita and we do not reject the validity of the surplus IV.
#' It should be noted that these tests were not designed for use with panel data.


#####################################################
#' --------- 15.30 ----------------------------------  
#####################################################

rm(list=ls())

suppressPackageStartupMessages(require(pacman))
#p_load(xtable,knitr,broom,dplyr,mosaic,AER,lmtest,car,plm)
p_load(mosaic,plm,stargazer)

#' Data definition file
#browseURL("http://www.principlesofeconometrics.com/poe5/data/def/crime.def")
load(url("http://www.principlesofeconometrics.com/poe5/data/rdata/crime.rdata"))

crimePDF <- pdata.frame(crime, index=c("county", "year"))
pdim(crimePDF)


lpolpc.red_form <- lm(lpolpc ~ lprbconv+lavgsen+lwmfg+west+urban+ltaxpc+lmix,
                      data=crime)
summary(lpolpc.red_form)

lprbarr.red_form <- lm(lprbarr ~ lprbconv+lavgsen+lwmfg+west+urban+ltaxpc+lmix,
                       data=crime)
summary(lprbarr.red_form)

require(car)
#' Test of joint significanse of the two IV
linearHypothesis(lpolpc.red_form, c("ltaxpc=0", "lmix=0"))
linearHypothesis(lprbarr.red_form, c("ltaxpc=0", "lmix=0"))

#' Note that for LPOLPC both instruments are significant and have a joint
#' F-statistic value of 20.835. For LBRBARR only LMIX is significant but the
#' joint F-test of significance is 113.52.
#' Recall from page 504 of POE5 that when there are 2
#' endogenous variables the two F-tests are not adequate to measure IV strength.
#' An alternative is discussed in Appendix 10A, the minimum eigenvalue statistic
#' or the Cragg-Donald F-statistic.
#' We can reject the null hypothesis that the IV are weak.

#' Hausman test
lcrmrte.ols_w_1stage_res <- lm(lcrmrte ~ lpolpc+lprbarr+lprbconv+lavgsen+lwmfg+west+urban+
                                 resid(lpolpc.red_form)+resid(lprbarr.red_form), data = crime)

summary(lcrmrte.ols_w_1stage_res)

#' The regression based on the Hausman test shows that the first stage
#' residuals are significant. The F-test of their joint significance is:
linearHypothesis(lcrmrte.ols_w_1stage_res, c("resid(lpolpc.red_form)=0", "resid(lprbarr.red_form)=0"))

#' We conclude that one or both of the variables LPOLPC and LPRBARR is endogenous.

require(sem)
#' 2SLS Estimation 
lcrmrte.2sls <- tsls(lcrmrte ~ lpolpc+lprbarr+lprbconv+lavgsen+lwmfg+west+urban,
                     ~ lprbconv+lavgsen+lwmfg+west+urban+ltaxpc+lmix,
                     data = crime)
summary(lcrmrte.2sls)

#' We see that LPOLPC and LPRBARR are insignificant.
#' LPRBCONV and LAVGSEN have negative coefficients and the
#' coefficient of the probability of conviction variable is significant.

#' Fixed Effects
lpolpc.fixed.red_form <- plm(lpolpc ~ lprbconv+lavgsen+lwmfg+ltaxpc+lmix,
                             data=crimePDF, model = "within")
summary(lpolpc.fixed.red_form)

lprbarr.fixed.red_form <- plm(lprbarr ~ lprbconv+lavgsen+lwmfg+ltaxpc+lmix,
                              data=crimePDF, model = "within")
summary(lprbarr.fixed.red_form)

#' We see that LMIX is a strong IV in both cases. The test of their
#' joint significance in the first reduced form is:
linearHypothesis(lpolpc.fixed.red_form, c("ltaxpc=0", "lmix=0"), test = "F")
linearHypothesis(lprbarr.fixed.red_form, c("ltaxpc=0", "lmix=0"), test = "F")
#' we reject the null hypothesis that the IV are weak.


#' 2sls
lcrmrte.fixed.2sls <- plm(lcrmrte ~ lpolpc+lprbarr+lprbconv+lavgsen+lwmfg
                          | lprbconv+lavgsen+lwmfg+west+urban+ltaxpc+lmix,
                          data=crimePDF, model = "within")

summary(lcrmrte.fixed.2sls)

#' e.
#' The results are once again not what we would expect, as LPOLPC has positive
#' and significant coefficient. LAVGSEN is now insignificant and the other 
#' two deterrence variables have negative coefficients

#' f.
lcrmrte.fixed.2sls_w_1st <- plm(lcrmrte ~ lpolpc+lprbarr+lprbconv+lavgsen+lwmfg+
                                  resid(lpolpc.fixed.red_form)+resid(lprbarr.fixed.red_form)
                                | lprbconv+lavgsen+lwmfg+west+urban+ltaxpc+lmix+
                                  resid(lpolpc.fixed.red_form)+resid(lprbarr.fixed.red_form),
                                data=crimePDF, model = "within")

summary(lcrmrte.fixed.2sls_w_1st)
linearHypothesis(lcrmrte.fixed.2sls_w_1st, c("resid(lpolpc.fixed.red_form)=0",
                                             "resid(lprbarr.fixed.red_form)=0"))
#' we find slight evidence of endogenetiy